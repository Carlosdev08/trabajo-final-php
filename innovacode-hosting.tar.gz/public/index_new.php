<?php
declare(strict_types=1);

// Activar errores para debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "Iniciando aplicación...<br>";

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CORE_PATH', BASE_PATH . '/core');
define('CONFIG_PATH', BASE_PATH . '/config');

echo "Constantes definidas<br>";

// Cargar configuración
if (!file_exists(CONFIG_PATH . '/env.php')) {
    die('ERROR: No se encontró el archivo env.php');
}
require_once CONFIG_PATH . '/env.php';
echo "env.php cargado<br>";

// Cargar autoloader
if (!file_exists(CORE_PATH . '/Autoloader.php')) {
    die('ERROR: No se encontró el archivo Autoloader.php');
}
require_once CORE_PATH . '/Autoloader.php';
echo "Autoloader.php cargado<br>";

// Ahora podemos usar las clases
use Core\Autoloader;
use Core\Helpers;
use Core\Router;
use Core\Session;

echo "Clases importadas<br>";

try {
    Autoloader::register([
        'App\\' => APP_PATH,
        'Core\\' => CORE_PATH,
    ]);
    echo "Autoloader registrado<br>";

    Session::start();
    echo "Sesión iniciada<br>";

    Helpers::setupErrors((bool) ($_ENV['APP_DEBUG'] ?? false));
    echo "Errores configurados<br>";

    $router = new Router();
    echo "Router creado<br>";

    $router->setBasePath(dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    echo "Base path configurado<br>";

    if (!file_exists(BASE_PATH . '/routes/web.php')) {
        die('ERROR: No se encontró el archivo routes/web.php');
    }
    require BASE_PATH . '/routes/web.php';
    echo "Rutas cargadas<br>";

    echo "Ejecutando router...<br>";
    $router->dispatch();

} catch (Exception $e) {
    echo "<strong>ERROR EXCEPTION:</strong> " . $e->getMessage() . "<br>";
    echo "<strong>Archivo:</strong> " . $e->getFile() . "<br>";
    echo "<strong>Línea:</strong> " . $e->getLine() . "<br>";
    echo "<strong>Trace:</strong><pre>" . $e->getTraceAsString() . "</pre>";
} catch (Error $e) {
    echo "<strong>FATAL ERROR:</strong> " . $e->getMessage() . "<br>";
    echo "<strong>Archivo:</strong> " . $e->getFile() . "<br>";
    echo "<strong>Línea:</strong> " . $e->getLine() . "<br>";
    echo "<strong>Trace:</strong><pre>" . $e->getTraceAsString() . "</pre>";
}
?>