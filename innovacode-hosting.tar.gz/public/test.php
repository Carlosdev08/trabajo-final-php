<?php
echo "PHP funciona correctamente!<br>";
echo "Fecha actual: " . date('Y-m-d H:i:s') . "<br>";

// Verificar si existe el archivo de configuración
$envPath = dirname(__DIR__) . '/config/env.php';
if (file_exists($envPath)) {
    echo "Archivo env.php existe<br>";
    require_once $envPath;
    echo "Base de datos configurada: " . ($_ENV['DB_NAME'] ?? 'No configurada') . "<br>";
} else {
    echo "Archivo env.php NO existe<br>";
}

// Verificar si existen los directorios necesarios
$dirs = [
    'app' => dirname(__DIR__) . '/app',
    'core' => dirname(__DIR__) . '/core',
    'config' => dirname(__DIR__) . '/config'
];

foreach ($dirs as $name => $path) {
    echo "Directorio $name: " . (is_dir($path) ? 'EXISTS' : 'NO EXISTE') . "<br>";
}
?>