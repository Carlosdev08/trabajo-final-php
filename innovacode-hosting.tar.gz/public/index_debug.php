<?php
use Core\Autoloader;
use Core\Helpers;
use Core\Router;
use Core\Session;
// Debug version del index.php
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "1. Iniciando...<br>";

try {
    echo "2. Definiendo constantes...<br>";
    define('BASE_PATH', dirname(__DIR__));
    define('APP_PATH', BASE_PATH . '/app');
    define('CORE_PATH', BASE_PATH . '/core');
    define('CONFIG_PATH', BASE_PATH . '/config');

    echo "3. Cargando env.php...<br>";
    require_once CONFIG_PATH . '/env.php';

    echo "4. Cargando Autoloader...<br>";
    require_once CORE_PATH . '/Autoloader.php';

    echo "5. Usando autoloader...<br>";

    echo "6. Registrando namespaces...<br>";
    Autoloader::register([
        'App\\' => APP_PATH,
        'Core\\' => CORE_PATH,
    ]);

    echo "7. Iniciando sesión...<br>";
    Session::start();

    echo "8. Configurando errores...<br>";
    Helpers::setupErrors((bool) ($_ENV['APP_DEBUG'] ?? false));

    echo "9. Creando router...<br>";
    $router = new Router();
    $router->setBasePath(dirname($_SERVER['SCRIPT_NAME'] ?? '/'));

    echo "10. Cargando rutas...<br>";
    require BASE_PATH . '/routes/web.php';

    echo "11. Ejecutando router...<br>";
    $router->dispatch();

} catch (Exception $e) {
    echo "<br>ERROR: " . $e->getMessage() . "<br>";
    echo "Archivo: " . $e->getFile() . "<br>";
    echo "Línea: " . $e->getLine() . "<br>";
} catch (Error $e) {
    echo "<br>FATAL ERROR: " . $e->getMessage() . "<br>";
    echo "Archivo: " . $e->getFile() . "<br>";
    echo "Línea: " . $e->getLine() . "<br>";
}
?>