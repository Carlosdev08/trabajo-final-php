<?php
// Activar todos los errores para debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Debug de errores PHP</h1>";

try {
    echo "<p>✅ PHP básico funciona</p>";

    // Verificar archivos necesarios
    $files = [
        'env.php' => dirname(__DIR__) . '/config/env.php',
        'Autoloader.php' => dirname(__DIR__) . '/core/Autoloader.php',
        'Router.php' => dirname(__DIR__) . '/core/Router.php'
    ];

    foreach ($files as $name => $path) {
        if (file_exists($path)) {
            echo "<p>✅ $name existe</p>";
        } else {
            echo "<p>❌ $name NO existe en: $path</p>";
        }
    }

    // Probar cargar env.php
    echo "<p>Cargando env.php...</p>";
    require_once dirname(__DIR__) . '/config/env.php';
    echo "<p>✅ env.php cargado correctamente</p>";
    echo "<p>DB_NAME: " . ($_ENV['DB_NAME'] ?? 'No definida') . "</p>";

    // Probar autoloader
    echo "<p>Cargando Autoloader...</p>";
    require_once dirname(__DIR__) . '/core/Autoloader.php';
    echo "<p>✅ Autoloader cargado</p>";

} catch (Exception $e) {
    echo "<p>❌ ERROR: " . $e->getMessage() . "</p>";
    echo "<p>Archivo: " . $e->getFile() . "</p>";
    echo "<p>Línea: " . $e->getLine() . "</p>";
} catch (Error $e) {
    echo "<p>❌ FATAL ERROR: " . $e->getMessage() . "</p>";
    echo "<p>Archivo: " . $e->getFile() . "</p>";
    echo "<p>Línea: " . $e->getLine() . "</p>";
}
?>