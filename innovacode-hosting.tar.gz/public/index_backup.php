<?php
use Core\Helpers;
use Core\Router;
use Core\Session;
use Core\Autoloader;
declare(strict_types=1);

// Activar errores para debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CORE_PATH', BASE_PATH . '/core');
define('CONFIG_PATH', BASE_PATH . '/config');

try {
    require_once CONFIG_PATH . '/env.php';
    require_once CORE_PATH . '/Autoloader.php';


    Autoloader::register([
        'App\\' => APP_PATH,
        'Core\\' => CORE_PATH,
    ]);

    Session::start();
    Helpers::setupErrors((bool) ($_ENV['APP_DEBUG'] ?? false));

    $router = new Router();
    $router->setBasePath(dirname($_SERVER['SCRIPT_NAME'] ?? '/'));

    require BASE_PATH . '/routes/web.php';

    $router->dispatch();

} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "<br>";
    echo "File: " . $e->getFile() . " Line: " . $e->getLine();
} catch (Error $e) {
    echo "FATAL ERROR: " . $e->getMessage() . "<br>";
    echo "File: " . $e->getFile() . " Line: " . $e->getLine();
}
?>