<?php
$_ENV['APP_NAME'] = 'InnovaCode MVC';
$_ENV['APP_URL'] = 'http://localhost/Trabajo-MasterD/innovacode/public';
$_ENV['APP_DEBUG'] = true;


$_ENV['DB_HOST'] = '127.0.0.1';
$_ENV['DB_PORT'] = 3306;
$_ENV['DB_NAME'] = 'newsletters';
$_ENV['DB_USER'] = 'root';
$_ENV['DB_PASS'] = '';